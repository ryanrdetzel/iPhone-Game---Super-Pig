//
//  main.m
//  When Pigs Fly
//
//  Created by Ryan on 10/10/08.
//  Copyright Fifth Floor Media 2008. All rights reserved.
//

#import <UIKit/UIKit.h>

int main(int argc, char *argv[]) {
    
    NSAutoreleasePool * pool = [[NSAutoreleasePool alloc] init];
    int retVal = UIApplicationMain(argc, argv, nil, nil);
    [pool release];
    return retVal;
}
