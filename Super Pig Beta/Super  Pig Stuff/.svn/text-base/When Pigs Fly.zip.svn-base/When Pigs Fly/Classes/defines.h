/*
 *  defines.h
 *  When Pigs Fly
 *
 *  Created by Ryan on 10/22/08.
 *  Copyright 2008 Fifth Floor Media. All rights reserved.
 *
 */

#define CLOUD 0
#define ROCK 1
#define MISC 2
#define SHIP 3
#define GRASS 4
#define SPHERE 5
#define POWERBALL 6
#define SCORE 7
#define DAMAGE 8
#define HEALTH 9

//#define CHEF_HAT 31
//#define SANTA_HAT 33
#define KING_HAT 34
#define PIRATE_HAT 32
#define JESTER_HAT 30

#define BONUS_FRIES 50
#define BONUS_SHAKE 51
#define BONUS_DONUT 53
#define BONUS_HAMBURGER 54
#define BONUS_HOTDOG 55
#define BONUS_PIZZA 56

//#define BONUS_STRAWBERRY 52

#define kSound_Thrust 0
#define kSound_Hit1 1
#define kSound_Hit2 2
#define kSound_Hit3 3
#define kSound_Hit4 4
#define kSound_Explosion 5
#define kSound_Boss1 6
#define kSound_Boss2 7
#define kSound_Fire 8
#define kSound_Ending1 9
#define kSound_PigDead 10
