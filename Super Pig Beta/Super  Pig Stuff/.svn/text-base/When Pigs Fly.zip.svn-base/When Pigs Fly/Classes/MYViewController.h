//
//  MYViewController.h
//  When Pigs Fly
//
//  Created by Ryan on 10/10/08.
//  Copyright 2008 Fifth Floor Media. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface MYViewController : UIViewController {

}

@end
